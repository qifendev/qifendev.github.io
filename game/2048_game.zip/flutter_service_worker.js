'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';
const RESOURCES = {
  "version.json": "a4d1e219cef485b189fca5938009f8dc",
"index.html": "63ebecc5fb99d72a6d1f7b5f50c29f1f",
"/": "63ebecc5fb99d72a6d1f7b5f50c29f1f",
"main.dart.js": "5264807435527ae98771f7dbdd7c0739",
"flutter.js": "a85fcf6324d3c4d3ae3be1ae4931e9c5",
"favicon.png": "f33e4487b7d0775dfcf2352cc62c8497",
"icons/Icon-192.png": "858aac314479d9ddb5025116bfe9360f",
"icons/Icon-maskable-192.png": "858aac314479d9ddb5025116bfe9360f",
"icons/Icon-maskable-512.png": "c89967faf4c184438b86c2c88d64912a",
"icons/Icon-512.png": "c89967faf4c184438b86c2c88d64912a",
"manifest.json": "7463f0442973b641b0d50d35d6232188",
"assets/AssetManifest.json": "3b730e58c40414ec7e6fc2d1c3b69726",
"assets/NOTICES": "0a49c93b44e11a1a38d361dea0f5f402",
"assets/FontManifest.json": "22ebc44567d856aa46a1dbfb2c3bb53e",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "6d342eb68f170c97609e9da345464e5e",
"assets/fonts/MaterialIcons-Regular.otf": "e7069dfd19b331be16bed984668fe080",
"assets/assets/images/svg/right-arrow.svg": "6cea882c007f21ec0c568c3075247e04",
"assets/assets/images/svg/play-game.svg": "b6ef05f68b06bd3a06e5d71c02c8be4c",
"assets/assets/images/svg/down-arrow.svg": "8792e8316d819d796df5ec0afa736fb3",
"assets/assets/images/svg/left-arrow.svg": "ee5d6e7d50611dddc54a9c9ae3f1c801",
"assets/assets/images/svg/save.svg": "952e93cc8c2d82340123619b8c6f509b",
"assets/assets/images/svg/up-arrow.svg": "83762a706cc85ecfd1f39236b206e7f3",
"assets/assets/images/svg/sound-adjust.svg": "81996b15221651a05fd51194b6505a7a",
"assets/assets/images/png/left-arrow.png": "0c69b9d104ff2b7beab876019c0eea61",
"assets/assets/images/png/down-arrow.png": "4bd5e461757f45fa19394d25ac73f299",
"assets/assets/images/png/right-arrow.png": "05b7b6202a9f3011e6f9bf187488c819",
"assets/assets/images/png/up-arrow.png": "24576a29b3771dbc2faa356666d24d57",
"assets/assets/images/png/game_icon.png": "e68d80c70ca45c44ea217a68ff86a503",
"assets/assets/audio/menu_button_click.mp3": "1d338b745c5fd8b5cd68c4b09544d1e7",
"assets/assets/audio/4.mp3": "e00bc3ecf20310761b1c7047ce7c058e",
"assets/assets/audio/4096.mp3": "00afef9d49bf5aa431ddabe0986d120f",
"assets/assets/audio/256.mp3": "7dcb91c1daa55ed4bef1a642338576d2",
"assets/assets/audio/32.mp3": "e38eefbb3bc9d4dab2d9f834e201f8ee",
"assets/assets/audio/512.mp3": "ec5652c2a38b8f1ca81358a52e96ab9d",
"assets/assets/audio/16.mp3": "0576aaa4af11d598f23b96c07bfcf46d",
"assets/assets/audio/128.mp3": "c320821d0230b3820b7393c9e104f7dd",
"assets/assets/audio/2048.mp3": "b4f2d810749f1d2f6f12ebd780870d0c",
"assets/assets/audio/1024.mp3": "220c1adf6737ff845921b5c33875bf20",
"assets/assets/audio/8.mp3": "dd7cc85c73fa59303894960107c51b6e",
"assets/assets/audio/64.mp3": "0afa0f1c7f208743d7450ccb5b4f8f31",
"assets/assets/fonts/Rubik/Rubik-Bold.ttf": "f70066a21af08705d0503ad692446de1",
"assets/assets/fonts/Rubik/Rubik-Light.ttf": "98df4209c27b1be565511cc954fa307d",
"assets/assets/fonts/Rubik/Rubik-Medium.ttf": "bb476f36e32039a411d1f3afaf5a81af",
"assets/assets/fonts/Rubik/Rubik-ExtraBold.ttf": "9f8c4a8202ef48c56a027ef49fbb2e35",
"assets/assets/fonts/Rubik/Rubik-Regular.ttf": "e100d91366c744a9fcf055b7c5af9961",
"assets/assets/fonts/Rubik/Rubik-BoldItalic.ttf": "8d5522a532a05a5a962b9e336261e1fb",
"canvaskit/canvaskit.js": "97937cb4c2c2073c968525a3e08c86a3",
"canvaskit/profiling/canvaskit.js": "c21852696bc1cc82e8894d851c01921a",
"canvaskit/profiling/canvaskit.wasm": "371bc4e204443b0d5e774d64a046eb99",
"canvaskit/canvaskit.wasm": "3de12d898ec208a5f31362cc00f09b9e"
};

// The application shell files that are downloaded before a service worker can
// start.
const CORE = [
  "main.dart.js",
"index.html",
"assets/AssetManifest.json",
"assets/FontManifest.json"];
// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});

// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});

// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache only if the resource was successfully fetched.
        return response || fetch(event.request).then((response) => {
          if (response && Boolean(response.ok)) {
            cache.put(event.request, response.clone());
          }
          return response;
        });
      })
    })
  );
});

self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});

// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}

// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
