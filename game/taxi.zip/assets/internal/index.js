System.register("chunks:///_virtual/internal",[],(function(){"use strict";return{execute:function(){}}}));
